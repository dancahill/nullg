<?php
$sys_username="administrator";
$sys_password="visual";
$sys_host="localhost";
$sys_port=4110;
?>
